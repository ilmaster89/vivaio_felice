package com.emit.project_work.vivaio_felice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VivaioFeliceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VivaioFeliceApplication.class, args);
	}

}
